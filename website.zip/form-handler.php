<?php
$name = $_POST['name'];
$visitor_email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

$email_from = 'chris@richtics.com'
$email_subject = 'new for submission'
$email_body = 'user name: $name.\n'.
              'user email: $visitor_email.\n'.
              'subject: $subject.\n'.
              'message: $message.\n';

$to = 'mr.chris.richter@gmail.com'
$headers = "From: $email_from \r\n";
$headers .= "Reply-To: $visitor_email \r\n";

mail($to, $email_subject, @email_body, $headers)

header("Location: contact.html")
?>
